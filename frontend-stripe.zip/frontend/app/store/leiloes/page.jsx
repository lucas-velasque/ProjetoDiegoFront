import LeiloesUsuarioClient from './ui/LeiloesUsuarioClient';

export const metadata = {
  title: 'Leilões | Loja',
};

export default function LeiloesPage() {
  return <LeiloesUsuarioClient />;
}
