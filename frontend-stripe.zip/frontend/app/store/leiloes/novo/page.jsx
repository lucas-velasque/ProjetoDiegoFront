import LeilaoUsuarioNovoClient from './ui/LeilaoUsuarioNovoClient';

export const metadata = {
  title: 'Novo leilão | Loja',
};

export default function NovoLeilaoPage() {
  return <LeilaoUsuarioNovoClient />;
}
