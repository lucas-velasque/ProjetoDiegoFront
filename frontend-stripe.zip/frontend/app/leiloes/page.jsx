import { redirect } from "next/navigation";

export default function LeiloesRedirect() {
  redirect("/store/leiloes");
}