
export default function PricingPage() {
    return (
        <div className='mx-auto max-w-[700px] my-28'>
            {/* Pricing Table */}

        </div>
    )
}